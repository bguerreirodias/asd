 <div class="col-md-3">
                    <div class="box" id="order-summary">
                        <div class="box-header">
                            <h3>Pedido</h3>
                        </div>
                        <p class="text-muted">Envio e custos adicionais serão calculados com base nos valores que você digitou</p>

                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Subtotal</td>
                                        <th>R$184.80</th>
                                    </tr>
                                    <tr>
                                        <td>Postagem e manuseio</td>
                                        <th>R$10.00</th>
                                    </tr>
                                    <tr>
                                        <td>Taxa</td>
                                        <th>R$5.00</th>
                                    </tr>
                                    <tr class="total">
                                        <td>Total</td>
                                        <th>R$199.80</th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>


                    <div class="box">
                        <div class="box-header">
                            <h4>Cupom</h4>
                        </div>
                        <p class="text-muted">Se você possui um cupom,digite-o no espaço abaixo</p>
                        <form>
                            <div class="input-group">

                                <input type="text" class="form-control">

                                <span class="input-group-btn">

					<button class="btn btn-primary" type="button"><i class="fa fa-gift"></i></button>

				    </span>
                            </div>
                            <!-- /input-group -->
                        </form>
                    </div>

                </div>
                <!-- /.col-md-3 -->