   <div class="navbar navbar-default yamm" role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand home" href="index.php" data-animate-hover="bounce">
                    <img src="img/logom.png" alt="Obaju logo" class="hidden-xs">
                    <img src="img/logo-small.png" alt="Obaju logo" class="visible-xs"><span class="sr-only">Conective - Página inicial</span>
                </a>
                <div class="navbar-buttons">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Navegação</span>
                        <i class="fa fa-align-justify"></i>
                    </button>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search">
                        <span class="sr-only">Pesquisar</span>
                        <i class="fa fa-search"></i>
                    </button>
                    <a class="btn btn-default navbar-toggle" href="basket.php">
                        <i class="fa fa-shopping-cart"></i>  <span class="hidden-xs">(3) Itens no carrinho</span>
                    </a>
                </div>
            </div>
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse" id="navigation">

                <ul class="nav navbar-nav navbar-left">
                    <li class="active"><a href="index.php">Página inicial</a>
                    </li>
                    <li class="dropdown yamm-fw">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200">Jogos <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <h5>Playstation</h5>
                                            <ul>
                                                <li><a href="category.php">Exclusivos</a>
                                                </li>
                                                <li><a href="category.php">Playstation 2</a>
                                                </li>
                                                <li><a href="category.php">Playstation 3</a>
                                                </li>
                                                <li><a href="category.php">Playstation 4</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-sm-3">
                                            <h5>Xbox</h5>
                                            <ul>
                                                <li><a href="category.php">Exclusivos</a>
                                                </li>
                                                <li><a href="category.php">Xbox 360</a>
                                                </li>
                                                <li><a href="category.php">Xbox One</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-sm-3">
                                            <h5>Nintendo</h5>
                                            <ul>
                                                <li><a href="category.php">Exclusivos</a>
                                                </li>
                                                <li><a href="category.php">Nintendo Wii</a>
                                                </li>
                                                <li><a href="category.php">Nintendo Wii-u</a>
                                                </li>
                                                <li><a href="category.php">Nintendo Switch</a>
                                                </li>
                                                <li><a href="category.php">Game cube</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-sm-3">
                                            <h5>PC</h5>
                                            <ul>
                                                <li><a href="category.php">Exclusivos</a>
                                                </li>
                                                <li><a href="category.php">Todos</a>
                                                </li>
                                            </ul>
                                            <h5>Portateis</h5>
                                            <ul>
                                                <li><a href="category.php">Exclusivos</a>
                                                </li>
                                                <li><a href="category.php">PSP</a>
                                                </li>
                                                <li><a href="category.php">PS Vita</a>
                                                </li>
                                                <li><a href="category.php">Nintento DS</a>
                                                </li>
                                                <li><a href="category.php">Nintento 3DS</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.yamm-content -->
                            </li>
                        </ul>
                    </li>



                    <li class="dropdown yamm-fw">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200">Sobre nós <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">
                                        <div class="col-sm-4"></div>
                                        <div class="col-sm-4"></div>
                                        <div class="col-sm-4">
                                            <ul>
                                                <li><a href="#"><b>História</b></a>
                                                </li>
                                                <li><a href="#"><b>Perguntas Frequentes</b></a>
                                                </li>
                                                <li><a href="#"><b>Unidades</b></a>
                                                </li>
                                                <li><a href="#"><b>Seja um franqueado</b></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.yamm-content -->
                            </li>
                        </ul>
                    </li>
                </ul>

            </div>
            <!--/.nav-collapse -->

            <div class="navbar-buttons">

                <div class="navbar-collapse collapse right" id="basket-overview">
                    <a href="basket.php" class="btn btn-primary navbar-btn"><i class="fa fa-shopping-cart"></i><span class="hidden-sm">(3) itens no carrinho</span></a>
                </div>
                <!--/.nav-collapse -->

                <div class="navbar-collapse collapse right" id="search-not-mobile">
                    <button type="button" class="btn navbar-btn btn-primary" data-toggle="collapse" data-target="#search">
                        <span class="sr-only">Pesquisar</span>
                        <i class="fa fa-search"></i>
                    </button>
                </div>

            </div>

            <div class="collapse clearfix" id="search">

                <form class="navbar-form" role="search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Pesquisar">
                        <span class="input-group-btn">

			<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>

		    </span>
                    </div>
                </form>

            </div>
            <!--/.nav-collapse -->

        </div>
        <!-- /.container -->
    </div>
    <!-- /#navbar -->
